import streamlit as st

st.title("Welcome to Streamlit")

name=st.text_input("Enter your name")
print(name)

if st.button("Greet me"):
    st.write(f"Hello, {name}!")
